package calculator;
import java.util.Scanner;
public class CalculatorTest {

	public static void main(String[] args) {
		runCalc();
	}
	
	public static void runCalc() {
	Calculator c = new Calculator();
	
	Scanner input = new Scanner(System.in);
	
	while(true) {
	
	System.out.println("Which operation would you like to do? add, subtract, multiply, divide, exponent, square root, modulate, or exit");
	String operation = input.nextLine().trim().toLowerCase();
	if(operation.equals("exit")) {
		System.out.println("Bye");
		break;
	}
	double first = 0.0;
	double second = 0.0;
	
	if (!operation.equals("square root")) {
        System.out.println("Enter First Number: ");
        first = input.nextDouble();
        System.out.println("Enter Second Number: ");
        second = input.nextDouble();
        input.nextLine();
    } else {
        System.out.println("Enter the number to find the square root: ");
        first = input.nextDouble();
        input.nextLine();
    }
	
	try {
	
	switch(operation){
	
	case "add":
		System.out.println("The answer is: " + String.format("%.2f", c.sum(first, second)));
		break;
	
	case "subtract":
		
		System.out.println("The answer is: " + String.format("%.2f", c.difference(first, second)));
		break;
	case "multiply":
		
		System.out.println("The answer is: " + String.format("%.2f", c.product(first, second)));
		break;
		
	case "divide":
		if(second != 0) {
		System.out.println("The answer is: " + String.format("%.2f", c.quotient(first, second)));
		}
		else {
			System.out.println("Division by 0 is not allowed");
		}
		break;
		
	case "exponent":
		
		System.out.println("The answer is: " + String.format("%.2f", c.exponent(first, second)));
		break;
		
	case "square root":
		if(first >= 0) {
		System.out.println("The answer is: " + String.format("%.2f", c.squareRoot(first)));
		}
		else {
			System.out.println("Square root of a negative number cannot happen");
		}
		break;
		
	case "modulate":
		if(second != 0) {
		System.out.println("The answer is: " + String.format("%.2f", c.modulator(first, second)));
		}
		else {
			System.out.println("Modulation by zero is not allowed");
		}
		break;
		
		default:
			System.out.println("This is not a valid operation. Try Again!");
			break;
	}
	
	}
	catch (IllegalArgumentException e) {
		System.out.println(e.getMessage());
	}
	
	}
	input.close();
}
}
