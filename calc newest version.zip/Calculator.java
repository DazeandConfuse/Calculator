package calculator;

public class Calculator {


		public double  sum(double x, double y) {
			return x + y;
			
			
		}
		public double difference(double x, double y) {
			return x - y;
			
		}
		public double product(double x, double y) {
			return x * y;
			
		}
		public double quotient(double x, double y) {
			if(y == 0) {
				throw new IllegalArgumentException("You cannot divide by zero");
			}
				return x / y;
				
		}
		public double exponent(double x, double y) {
			return Math.pow(x, y);
			 
		}
		public double squareRoot(double x) {
			if(x < 0) {
				throw new IllegalArgumentException("You cannot square root a negative number");
			}
			return Math.sqrt(x);
			
			
		}
		public double modulator(double x , double y) {
			if(y == 0) {
				throw new IllegalArgumentException("You cannot modulate by zero.");
			}
			return x % y;
			
			
		}
		
		
		}
